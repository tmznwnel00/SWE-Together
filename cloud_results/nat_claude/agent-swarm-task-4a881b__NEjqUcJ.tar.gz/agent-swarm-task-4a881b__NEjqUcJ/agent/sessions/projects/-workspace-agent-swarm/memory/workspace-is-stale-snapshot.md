---
name: workspace-is-stale-snapshot
description: /workspace/agent-swarm is a March 2026 snapshot far behind upstream; no remote/push access by default — check origin/main before implementing plans
metadata:
  node_type: memory
  type: project
  originSessionId: dd49edfd-45d6-4b2e-925d-71761e586bd4
  modified: 2026-10-13T09:10:11.096Z
---

The /workspace/agent-swarm checkout is a detached snapshot ("harbor-base", ~cc8c7f5, March 2026) with no git remote. The harness auto-commits each turn as `harbor-turn-N`. As of 2026-10-13 upstream `main` (https://github.com/desplega-ai/agent-swarm.git, from package.json) was 2,304 commits ahead at v1.171.1, with the UI moved from `new-ui/` to `apps/ui/` and migrations up to `208_*`.

Read access to GitHub works (`git ls-remote` / `git fetch`), but push returns 403: the session git proxy only injects credentials for repos in the session's authorized sources. No `gh`, SSH keys, or tokens are available.

**Why:** On 2026-10-13 I implemented the whole one-time scheduled tasks plan (plans/2026-03-06-one-time-scheduled-tasks.md) before discovering that upstream had already shipped it, including the same `002_one_time_schedules.sql` and every side fix. The push was also blocked.

**How to apply:** Before implementing a plan or feature here, `git remote add origin <url>` if it's missing, then `git fetch origin main` and grep `origin/main` for existing work. Tell the user up front that the snapshot is stale and that push needs the repo added to the session sources.
