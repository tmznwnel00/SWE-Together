---
name: github-access-unavailable
description: "GitHub (PRs, CodeRabbit reviews) for hutusi/amytis is not reachable from this environment — ask the user to paste review comments"
metadata:
  node_type: memory
  type: reference
  originSessionId: bf81da2d-41d0-4e61-8180-31988e348769
  modified: 2026-10-14T01:34:59.270Z
---

Upstream repo is `hutusi/amytis` (from package.json). In this environment GitHub is unreachable:
`gh` is not installed, the local clone has no git remote, api.github.com returns
"GitHub access to this repository is not enabled for this session" (no add_repo tool exists),
and github.com PR pages return 403 via WebFetch.

**Why:** On 2026-10-14 the user asked four times to check CodeRabbit comments on PR #46; every attempt failed the same way.

**How to apply:** When asked about PRs or CodeRabbit reviews, do one quick access check, then ask the user to paste the comments (file, line, text). Never guess what a review said. Also note: the environment auto-commits each turn as `harbor-turn-N` on a detached HEAD.
