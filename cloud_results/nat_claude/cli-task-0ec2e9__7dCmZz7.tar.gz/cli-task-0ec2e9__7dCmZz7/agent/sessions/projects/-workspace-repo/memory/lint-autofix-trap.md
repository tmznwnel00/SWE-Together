---
name: lint-autofix-trap
description: "Running golangci-lint directly in this repo rewrites files (fix: true); use pinned version with --fix=false"
metadata:
  node_type: memory
  type: project
  originSessionId: ed067852-ff70-4196-ac2d-016fe789fe6d
  modified: 2026-10-14T02:03:51.911Z
---

`.golangci.yaml` sets `fix: true`, so any direct `golangci-lint run` silently rewrites unrelated files. When `mise` is unavailable (sandbox), install the version pinned in `mise.toml` (2.10.1 as of 2026-10) and run with `--fix=false --build-tags integration --new-from-rev=<base>`.

**Why:** On 2026-10-14 an unpinned 2.14 run stripped `//nolint:gosec` G115 directives (newer gosec no longer flags them, but CI's 2.10.1 does) and a perfsprint fix left `integration_test/interactive.go` without an `errors` import, breaking the integration build.

**How to apply:** Never run golangci-lint here without `--fix=false`; check `git status` for files you didn't intend to touch after any lint run.
